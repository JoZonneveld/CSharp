# INFDEV02-3
Statically typed, polymorphic object oriented programming course at Rotterdam University of applied sciences

To build the modulewijzer run:
```
pdflatex Modulewijzer\ INFDEV02-3.tex
makeglossaries Modulewijzer\ INFDEV02-3
pdflatex Modulewijzer\ INFDEV02-3.tex
pdflatex Modulewijzer\ INFDEV02-3.tex
```