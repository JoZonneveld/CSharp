<<<<<<< HEAD
﻿open Compile

[<EntryPoint>]
let main argv = 
//  do batchProcess LatexDefinition.generateDocument Dev2.SampleExams.exam1 "INFDEV02_2_sample_exam1" "The INFDEV team" "Sample exam 1" true false

//  do batchProcess LatexDefinition.generateDocument Dev2.SampleExams.exam2 "INFDEV02_2_sample_exam2" "The INFDEV team" "Sample exam 2" true false
//  do batchProcess LatexDefinition.generateDocument Dev2.SampleExams.exam3 "INFDEV02_2_sample_exam1" "The INFDEV team" "Sample exam 3" true false
//  do batchProcess LatexDefinition.generateDocument Dev2.SampleExams.exam4 "INFDEV02_2_sample_exam1" "The INFDEV team" "Sample exam 4" true false
//  do batchProcess LatexDefinition.generateDocument Dev2.SampleExams.exam5 "INFDEV02_2_sample_exam1" "The INFDEV team" "Sample exam 5" true false

//  do batchProcess LatexDefinition.generateDocument Dev3.SampleExams.exam1 "INFDEV02_3_sample_exam1" "The INFDEV team" "Sample exam 1" true false
//  do batchProcess LatexDefinition.generateDocument Dev3.SampleExams.exam2 "INFDEV02_3_sample_exam2" "The INFDEV team" "Sample exam 2" true false
//  do batchProcess LatexDefinition.generateDocument Dev3.SampleExams.exam3 "INFDEV02_3_sample_exam3" "The INFDEV team" "Sample exam 3" true false

  do batchProcess LatexDefinition.generatePresentation Chapter1.Week1_2.slides "INFDEV02_3_Lec1_OO_intro" "The INFDEV team" "Introduction" false true
//  do batchProcess LatexDefinition.generatePresentation Chapter1.Week3.slides "INFDEV02_3_Lec2_Static_typing" "The INFDEV team" "Type systems" false true
//  do batchProcess LatexDefinition.generatePresentation Chapter2.Week4.slides "INFDEV02_3_Lec3_Polymorphism" "The INFDEV team" "Polymorphism" true false
//  do batchProcess LatexDefinition.generatePresentation Chapter3.Week5.slides "INFDEV02_3_Lec4_Generics" "The INFDEV team" "Generics" true false
//  do batchProcess LatexDefinition.generatePresentation Chapter4.Week6.slides "INFDEV02_3_Lec5_PatternsAndPractices" "The INFDEV team" "Patterns and practices" false true

//  do batchProcess LatexDefinition.generatePresentation StateTraceSamples.slides "test" "The INFDEV team" "test" true false
  0

// arrays
// lambdas
=======
﻿open Compile

[<EntryPoint>]
let main argv = 
//  do batchProcess LatexDefinition.generateDocument Dev2.SampleExams.exam1 "INFDEV02_2_sample_exam1" "The INFDEV team" "Sample exam 1" true false

//  do batchProcess LatexDefinition.generateDocument Dev2.SampleExams.exam2 "INFDEV02_2_sample_exam2" "The INFDEV team" "Sample exam 2" true false
//  do batchProcess LatexDefinition.generateDocument Dev2.SampleExams.exam3 "INFDEV02_2_sample_exam1" "The INFDEV team" "Sample exam 3" true false
//  do batchProcess LatexDefinition.generateDocument Dev2.SampleExams.exam4 "INFDEV02_2_sample_exam1" "The INFDEV team" "Sample exam 4" true false
//  do batchProcess LatexDefinition.generateDocument Dev2.SampleExams.exam5 "INFDEV02_2_sample_exam1" "The INFDEV team" "Sample exam 5" true false

  do batchProcess LatexDefinition.generateDocument Dev3.SampleExams.exam1 "INFDEV02_3_sample_exam1" "The INFDEV team" "Sample exam 1" true false
  //do batchProcess LatexDefinition.generateDocument Dev3.SampleExams.exam2 "INFDEV02_3_sample_exam2" "The INFDEV team" "Sample exam 2" true false
//  do batchProcess LatexDefinition.generateDocument Dev3.SampleExams.exam3 "INFDEV02_3_sample_exam3" "The INFDEV team" "Sample exam 3" true false

//  do batchProcess LatexDefinition.generatePresentation Chapter1.Week1_2.slides "INFDEV02_3_Lec1_OO_intro" "The INFDEV team" "Introduction" false true
//  do batchProcess LatexDefinition.generatePresentation Chapter1.Week3.slides "INFDEV02_3_Lec2_Static_typing" "The INFDEV team" "Type systems" false true
//  do batchProcess LatexDefinition.generatePresentation Chapter2.Week4.slides "INFDEV02_3_Lec3_Polymorphism" "The INFDEV team" "Polymorphism" true false
//  do batchProcess LatexDefinition.generatePresentation Chapter3.Week5.slides "INFDEV02_3_Lec4_Generics" "The INFDEV team" "Generics" true false
//  do batchProcess LatexDefinition.generatePresentation Chapter4.Week6.slides "INFDEV02_3_Lec5_PatternsAndPractices" "The INFDEV team" "Patterns and practices" false true

//  do batchProcess LatexDefinition.generatePresentation StateTraceSamples.slides "test" "The INFDEV team" "test" true false
  0

// arrays
// lambdas
>>>>>>> origin/master
