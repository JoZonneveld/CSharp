package chapter4.car;

public interface Gearbox extends PowerTrainComponent {
}
