package chapter4.car;

public interface PowerTrainComponent extends Component{
    float turn(float rpm);
}
