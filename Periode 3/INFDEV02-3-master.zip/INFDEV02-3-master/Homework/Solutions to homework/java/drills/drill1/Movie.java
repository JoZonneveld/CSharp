package drills.drill1;

public class Movie {
    String title;
    String genre;
    int rating;


    void playIt(){
        System.out.printf("Playing the movie: %s", title);
    }


}
