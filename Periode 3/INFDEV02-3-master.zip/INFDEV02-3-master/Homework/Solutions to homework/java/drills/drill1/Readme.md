These drill exercises can help you practice and understand individual concepts shown in the lessons.

Sum: Calculate the sum between two given numbers
Triangle: Draw a triangle on the console, just like in DEV01
BeerSong: An example from Head First Java(p. 14).
Car: Similar to the car-class we've seen in dev02
IntArray: Practice with an array of integers
UserStory: Practice with an array of Objects

