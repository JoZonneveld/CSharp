These drill exercises can help you practice and understand individual concepts shown in the lessons.

Encapsulation
