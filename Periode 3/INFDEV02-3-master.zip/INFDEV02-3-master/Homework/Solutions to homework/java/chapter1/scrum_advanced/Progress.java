package chapter1.scrum_advanced;

public enum Progress {
    TODO, INPROGRESS, VERIFY, DONE
}
