package chapter3.trafficlight_advanced.trafficlight;

enum Color {
    Red, Green, Yellow
}

