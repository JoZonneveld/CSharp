package chapter3.trafficlight_advanced.trafficlight;

interface Event {
    void perform();
}


