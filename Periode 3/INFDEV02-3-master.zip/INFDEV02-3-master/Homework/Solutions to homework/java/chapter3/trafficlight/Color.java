package chapter3.trafficlight;

enum Color {
    Red, Green, Yellow
}

