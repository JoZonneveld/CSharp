package exercises.exercise2.fuels;

public abstract class Fuel {
    private int amount;

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
