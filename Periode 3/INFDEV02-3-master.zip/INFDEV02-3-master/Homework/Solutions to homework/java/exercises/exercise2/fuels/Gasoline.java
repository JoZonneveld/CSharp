package exercises.exercise2.fuels;

public class Gasoline extends Fuel {
    public Gasoline(int amount) {
        setAmount(amount);
    }
}
