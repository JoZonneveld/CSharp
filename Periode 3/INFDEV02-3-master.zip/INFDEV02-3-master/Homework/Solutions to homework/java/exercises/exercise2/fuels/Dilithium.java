package exercises.exercise2.fuels;

public class Dilithium extends Fuel {
    public Dilithium(int amount) {
        setAmount(amount);
    }
}
