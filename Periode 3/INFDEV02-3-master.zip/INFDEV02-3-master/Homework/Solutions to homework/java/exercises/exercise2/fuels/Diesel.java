package exercises.exercise2.fuels;

public class Diesel extends Fuel {

    public Diesel(int amount) {
        setAmount(amount);
    }
}