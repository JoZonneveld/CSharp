package exercises.exercise3;

public enum Color {
    Red, Green, Yellow
}
