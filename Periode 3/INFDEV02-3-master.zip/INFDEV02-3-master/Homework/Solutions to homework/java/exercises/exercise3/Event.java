package exercises.exercise3;

public interface Event {
    void perform();
}
