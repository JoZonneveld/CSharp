package exercises.exercise4;

public interface Gearbox extends PowerTrainComponent {
}
