package exercises.exercise4;

public interface Component {
}
