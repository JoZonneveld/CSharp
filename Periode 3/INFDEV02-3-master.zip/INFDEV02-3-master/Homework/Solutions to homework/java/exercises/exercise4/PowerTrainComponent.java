package exercises.exercise4;

public interface PowerTrainComponent extends Component{
    float turn(float rpm);
}
