package chapter2.fuels;

public interface IFuel {
    public int getAmount();

    public void setAmount(int amount);

}
