package chapter2.persons;

public interface Person {
    String getName();
    String getSurname();
    int getAge();
}
