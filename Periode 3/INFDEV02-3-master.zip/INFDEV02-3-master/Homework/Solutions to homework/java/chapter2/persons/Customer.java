package chapter2.persons;

public class Customer implements Person {

    @Override
    public String getName() {
        return null;
    }

    @Override
    public String getSurname() {
        return null;
    }

    @Override
    public int getAge() {
        return 0;
    }
}
