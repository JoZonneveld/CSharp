package chapter2.animals;

public class Main {
    public static void main(String[] args) {
        Animal animal1 = new Cat();
        Animal animal2 = new Dog();
        Animal animal3 = new Cow();

        animal1.saySomething();
        animal2.saySomething();
        animal3.saySomething();

    }
}
