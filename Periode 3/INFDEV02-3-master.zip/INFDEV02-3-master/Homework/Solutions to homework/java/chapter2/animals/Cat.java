package chapter2.animals;

public class Cat implements Animal{

    @Override
    public void saySomething() {
        System.out.println("Miao...");
    }
}