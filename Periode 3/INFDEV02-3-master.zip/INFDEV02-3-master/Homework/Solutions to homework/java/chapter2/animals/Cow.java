package chapter2.animals;

public class Cow implements Animal{

    @Override
    public void saySomething() {
        System.out.println("Muuu...");
    }
}
