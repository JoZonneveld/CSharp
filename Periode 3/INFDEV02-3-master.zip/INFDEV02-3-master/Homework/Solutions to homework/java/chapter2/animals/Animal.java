package chapter2.animals;

public interface Animal {
    void saySomething();
}
