package chapter2.animals;

public class Dog implements Animal{

    @Override
    public void saySomething() {
        System.out.println("Bao...");
    }
}