package chapter2.fuels_advanced;

public class Gasoline extends AbstractFuel {
    public Gasoline(int amount) {
        setAmount(amount);
    }
}
