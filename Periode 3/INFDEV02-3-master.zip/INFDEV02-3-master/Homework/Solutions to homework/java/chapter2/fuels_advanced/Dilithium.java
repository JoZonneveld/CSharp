package chapter2.fuels_advanced;

public class Dilithium extends AbstractFuel {
    public Dilithium(int amount) {
        setAmount(amount);
    }
}
