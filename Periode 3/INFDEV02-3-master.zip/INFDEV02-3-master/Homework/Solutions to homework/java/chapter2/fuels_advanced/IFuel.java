package chapter2.fuels_advanced;

public interface IFuel {
    public int getAmount();

    public void setAmount(int amount);

}
