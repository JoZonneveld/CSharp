package chapter2.fuels_advanced;

public class Diesel extends AbstractFuel {
    public Diesel(int amount) {
        setAmount(amount);
    }
}