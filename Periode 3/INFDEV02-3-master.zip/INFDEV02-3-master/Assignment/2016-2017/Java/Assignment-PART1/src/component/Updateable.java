package component;

public interface Updateable{
    void update(float dt);
}